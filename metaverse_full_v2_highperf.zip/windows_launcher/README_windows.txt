Run start_windows.bat to launch backend and open frontend in browser.
