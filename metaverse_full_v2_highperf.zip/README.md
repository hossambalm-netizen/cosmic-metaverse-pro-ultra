Metaverse Super Platform — High Performance Dual Build (v2_highperf)
See docs for instructions.
